def functionOne():
    #My functions here don't have docstrings.  Do as I say, not as I do
    print(globaVariable):
    #This variable is global (or will be when I declare it in a bit)
    localVariable="hello" #This variable is local to functionOne.  I can use it within the function
    print (localVariable)

def functionTwo(parameter): #The passed argument is local to the function
    #docstring here
    print (parameter) #So I can use it here

def functionThree():
  #docstring here
    globalNumericVariable = globalNumericVariable + 6 #ERROR! I can now access the global variable but i can modify it specifically what happened is a new variable called globalNumericVariable has been created that is local to the function

    global globalNumericValue 
    globalNumericVariable = globalNumericVariable + 6
    print(globalNumericVariable)
    #this will work as expected to do so

globalVariable = 6 #this variable is used outside any functions or loops, it can be used anywhere in the progam 
print (globalVariable)#it can be used here
print (localVariable)#but, localVariable is local to function0ne
function0ne()
print (localVariable) #this still does not work, even though function0ne has run, the variable does not exist outside of the function
functionTwo("function two variable")
globalNumericVariable = 6 #again global as its referenced outside of a function 
functionThree()