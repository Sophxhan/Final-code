#this is an example of a sequence 
#sequences are intuituve, do one line and another, etc...
print("I like that boulder")
print("That is a niceeee")
print("Boulder")