def functionOne():
    #My functions here don't have docstrings.  Do as I say, not as I do
    print(globaVariable)#This variable is global (or will be when I declare it in a bit)
    localVariable="hello" #This variable is local to functionOne.  I can use it within the function
    print (localVariable)

def functionTwo(parameter): #The passed argument is local to the function
    #docstring here
    print (parameter) #So I can use it here

def functionThree():
    globalNumericVariable = globalNumericVariable + 6 
    global globalNumericValue 
    globalNumericVariable = globalNumericVariable + 6
    print(globalNumericVariable)

globalVariable = 6 
print (globalVariable)
print (localVariable)
functionOne()
print (localVariable)
functionTwo("function two variable")
globalNumericVariable = 6 
functionThree()