def printHello(): 
    print("Silly Goose")
    return True 

def addTwoNumbers(h, s):
    """Prints the sum of two numbers

    Keyword Arguments:
    h - the first number
    s - the second number
    """
    print(str(h+s))
    return h+s 

def raiseToPower(base, index=8):
    """Prints the value of a number raised to a power

    Keyword Arguments:
    base - the base number
    index - the power to raise base to (default 8)
    """
    print (str(base**index))
    return base**index

printHello()
resultsFromHello = printHello()
print(resultsFromHello)
addTwoNumbers(2,8)
firstNumber = 2
secondNumber = 8
addTwoNumbers(2,8)
raiseToPower(2,addTwoNumbers(2,8)) 