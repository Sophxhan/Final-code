import math #Libraries are just a collection of extra commands in Python that do specific jobs. "Math" does a bunch of maths-type jobs
print(math.pi) #this is to access a command from a library we have access to use
import matplotlib as mpl#matplotlib is used for drawing up graphs and charts. Like here, we have used the "as" a keyword which then will temporarily rename "matplotlib" to "mlp"
mpl.rcParams['lines.linewidth'] = 3#i am now able to set the line width of my graphs to two, as well as do other matplotlib bits and bats without typing out matplotlib everytime from a PIL import image #PIL is known as the Python Image Library.
from PIL import Image 
#There's a lot of manipulating imagary, in this next part though i've just imported a specific class, image, from the library
im = Image.open("python code.PNG")#i can then use this class without reffering to it - i do not need to write PIL.image
from numpy import arange as rng #i can now combine these things if i wish to do so. Numpy has high level math techniques - here im importing the arange class from numpy as well as renaming it ar, which means i can do this - 
a = rng(18) #this means i can now write this instead of a= numpy.arange(18), i can also do this -
from numpy import * 
#the star basically means if there's a football you would then have to explain exactly what this means so it's not the smartest idea to use this