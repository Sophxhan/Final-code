import random

#this is an example of selection")
#this program will choose which statements to work on based on the conditions 
#a simple 'if' statement will do an instruction if a condition is met
firstRan = random.randint(1,20)
if (firstRan==20): #its important to notice that the colon at the end of the line and the indent at the start of the next 
    print("I just picked a random number.  You'll only see this line if it was a twenty.  If it wasn't, this line doesn't appear")
#adding an 'else' clause tot he 'if' statement will allow us to have one thing if the condition is met and a different thing if it isn't
secondRan = random.randint(1,20)
if (secondRan>10):
    print("I picked another random number.  You'l only see this message if it's above 10")
else: #colon, indent. else doesn't need a condition though - its condition is basically "the first one isnt met
    print("I picked a random number above this, however you could only see this if it was above 10, and it wasn't therefore you could not view this message.")
#we have many options, we can add 'elif' blocks. these functions are the same as if blocks")
thirdRan=random.randint(1,20)
if (thirdRan==4):
    print("I picked yet another number.  You'll see this line if it was four")
elif (thirdRan==7):#colon, indent
    print("I picked yet another number.  You'll see this line if it was seven")
else:
    print("I picked yet another number.  You'll see this line if it neither four nor seven")
    #each individual part us surrounded by "s but there is only one set of brackets
    print("We can also have multiple lines inside an 'if', 'elif' or 'else'.  "
           "will only appear if the number was neither four nor seven, like the one above")
#the order of instructions remain the same, its similar to a sequence however the computer makes the decision as to which line to use")
        