
print("I like that boulder")
print("That is a niceeee")
print("Boulder")