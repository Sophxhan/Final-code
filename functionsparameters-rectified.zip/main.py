def printHello(): #this function does not take any debate, we do still need the brackets though
    print("Silly Goose") #functions need docstrings, these are descriptions of what the function does
    return True #realistically every function should send something back, as not much here is useful ive used the statement "true" to confirm this is a function 

def addTwoNumbers(h, s): #this function will take two arguments that here have been called h and s
    """Prints the sum of two numbers

    Keyword Arguments:
    h - the first number
    s - the second number
    """ #this is known as a multiine docstring, it says exactly what the function does as well as what arugment it takes
    print(str(h+s))
    return h+s #useful information to send back

def raiseToPower(base, index=8): #this will take one of the arguments and another optional argument. if then two are given that is absoulutely fine, however, if there is only one the second one will default to 2
    """Prints the value of a number raised to a power

    Keyword Arguments:
    base - the base number
    index - the power to raise base to (default 8)
    """
    print (str(base**index))
    return base**index
#a function can be called by writing it's name and then brackets
printHello()
#i can then store the return value of the function in a variable
resultsFromHello = printHello()
print(resultsFromHello)
#if the function then takes the arguments i will provide them inside a bracket
addTwoNumbers(2,8)
#i am also able to pass it variables 
firstNumber = 2
secondNumber = 8
addTwoNumbers(2,8)
#as well as being able to output other functions
raiseToPower(2,addTwoNumbers(2,8)) #we would start with the first pair of brackets. so addTwoNumbers(2,8), this would return to 10, then do raiseToPower(8,2). If i shifted raiseToPower down after this line, this program would not work properly.