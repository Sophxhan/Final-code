import random

for s in range(2):
    print ("hello")
for s in range(2,8):
    print ("hello")
print ("did you get it right?")
print ("the counter starts at 2, does the instructions.  It then goes to three, which is below eight, then to four, which is below eight, then to five, which is below eight, then to six, which is below eight, then to seven which is below eight, so it does the instructions.  It then goes to eight"
       "which isn't below eight, so it stops.")
input()
for s in range (10,30,2):
    print ("hello")
for s in range(10,30,2):
    print ("The counter is: " + str(s))
parts=["colin", "the", "happy", "caterpillar"]
for s in parts:
    print(s)
for s in parts:
    print(s)
    if (s=="caterpillar"):
        print ("you'know")
loopCounter = 0;
while loopCounter<8:
    print ("I'm in a while loop")
    loopCounter+=1 
