import random
#this code really is about doing the same thing multiple times. we are looking at two ways of doing this, for the loop to repeat its tasks a certain number of times
#for s in range([start], stop, [step]): start and step are optional choices so realistically we could just print something a few times with 'for s in range(2):'")
for s in range(2): #colon, indent
    print ("hello")
    #this loop starts the counter at 0 and then proceeds with the instructions then increases the counter til it reaches 2, it will not do it the second time")
for s in range(2,8):
    print ("hello")
print ("did you get it right?")
print ("the counter starts at 2, does the instructions.  It then goes to three, which is below eight, then to four, which is below eight, then to five, which is below eight, then to six, which is below eight, then to seven which is below eight, so it does the instructions.  It then goes to eight"
       "which isn't below eight, so it stops.")
input()
for s in range (10,30,2):
    print ("hello")
#the counter starts at zero, this time it goes up in 2s, for exaple: 0,2,4,6,8 - eight times. We can see this more clear if we print the counter")
for s in range(10,30,2):
    print ("The counter is: " + str(s))
#next type of iteration is being able to iterate through a list, this is a type of loop, often times we set up an item list so this is setting one up.
parts=["colin", "the", "happy", "caterpillar"]
#you can print out every item in this list like this:")
for s in parts: #colon, indent
    print(s)
#we can indent different things in other things:")
for s in parts:
    print(s)
    if (s=="caterpillar"):
      #colon, indent
        print ("you'know")#this means we now intent two steps
  #this comment is now inside of the loop and not inside the if
#this comment is in neither

loopCounter = 0;
#this is a while loop. this loop does something a certain number of times, a while loop does something as long as the condition is met")
#there's again colons and indenting. it looks like this:")
while loopCounter<8:
    print ("I'm in a while loop")
    loopCounter+=1#this means increase the loopCounter variable
