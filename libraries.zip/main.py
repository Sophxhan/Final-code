import math 
print(math.pi) 
import matplotlib as mpl
mpl.rcParams['lines.linewidth'] = 3
from PIL import Image 
im = Image.open("python code.PNG") 
from numpy import arange as rng 
a = rng(18) 
from numpy import * 