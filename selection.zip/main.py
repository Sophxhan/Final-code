import random


firstRan = random.randint(1,20)
if (firstRan==20): 
    print("I just picked a random number.  You'll only see this line if it was a twenty.  If it wasn't, this line doesn't appear")

secondRan = random.randint(1,20)
if (secondRan>10):
    print("I picked another random number.  You'l only see this message if it's above 10")
else: 
    print("I picked a random number above this, however you could only see this if it was above 10, and it wasn't therefore you could not view this message.")

thirdRan=random.randint(1,20)
if (thirdRan==4):
    print("I picked yet another number.  You'll see this line if it was four")
elif (thirdRan==7):
    print("I picked yet another number.  You'll see this line if it was seven")
else:
    print("I picked yet another number.  You'll see this line if it neither four nor seven")
    
    print("We can also have multiple lines inside an 'if', 'elif' or 'else'.  "
           "will only appear if the number was neither four nor seven, like the one above")

        